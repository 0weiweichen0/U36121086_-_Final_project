# dqn_agent

import random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from agents.dqn_model import DQN

class DQNAgent:
    def __init__(self, state_shape, action_dim, device): # 初始化網路與超參數
        self.device = device
        self.action_dim = action_dim

        # 建立兩個網路：主網路與目標網路
        self.policy_net = DQN(input_channels=state_shape[0], num_actions=action_dim).to(device)
        self.target_net = DQN(input_channels=state_shape[0], num_actions=action_dim).to(device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()  # 固定 target network

        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=1e-4)

        # ε-greedy 參數
        self.epsilon = 1.0
        self.epsilon_min = 0.01
        self.epsilon_decay_rate = 0.99  # 越接近 1，越慢減少

        # 初始化
        self.gamma = 0.99


    def select_action(self, state): # ε-greedy 策略選動作        
        """用 ε-greedy 策略從 state 選一個動作"""
        if random.random() < self.epsilon:
            return random.randint(0, self.action_dim - 1)  # 隨機探索
        else:
            state = torch.FloatTensor(state).unsqueeze(0).to(self.device)  # shape: (1, 4, 84, 84)
            with torch.no_grad():
                q_values = self.policy_net(state)
            return q_values.argmax().item()

    def update(self, batch): # 從記憶庫訓練一次
        """從 replay buffer 取出 batch 進行訓練"""
        states, actions, rewards, next_states, dones = batch

        # 轉換為 Tensor
        states = torch.FloatTensor(states).to(self.device)
        actions = torch.LongTensor(actions).unsqueeze(1).to(self.device)
        rewards = torch.FloatTensor(rewards).unsqueeze(1).to(self.device)
        next_states = torch.FloatTensor(next_states).to(self.device)
        dones = torch.FloatTensor(dones).unsqueeze(1).to(self.device)

        # 計算 Q(s,a)
        q_values = self.policy_net(states).gather(1, actions)

        # 計算 target Q(s', a')（只在非終止狀態才考慮未來獎勵）
        with torch.no_grad():
            max_next_q = self.target_net(next_states).max(1)[0].unsqueeze(1)
            expected_q = rewards + (1 - dones) * self.gamma * max_next_q

        loss = nn.functional.mse_loss(q_values, expected_q)

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        return loss.item()

    def update_target_network(self): # 將主網路參數複製給目標網路
        """同步 target_net 與 policy_net"""
        self.target_net.load_state_dict(self.policy_net.state_dict())


    def decay_epsilon(self, episode=None):
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay_rate)


