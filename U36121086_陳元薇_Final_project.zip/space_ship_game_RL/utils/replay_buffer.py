# replay_buffer
# 記憶池等工具

# utils/replay_buffer.py

import random
from collections import deque
import numpy as np

class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        """儲存一筆 (s, a, r, s', done) 經驗"""
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        """隨機抽樣 batch"""
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = map(np.array, zip(*batch))
        return states, actions, rewards, next_states, dones

    def __len__(self):
        return len(self.buffer)
