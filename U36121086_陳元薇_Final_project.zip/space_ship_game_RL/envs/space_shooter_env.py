### RL環境包裝

import numpy as np
import cv2
import pygame
import os
import sys

# 加入上層目錄以匯入 game_core
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from game_core.game import Game

class SpaceShooterEnv:
    def __init__(self, frame_stack=4, use_gray=True, render_mode=False):
        self.frame_stack = frame_stack
        self.use_gray = use_gray
        self.render_mode = render_mode  # 準備用於關閉render for train
        self.state_shape = (84, 84)  # 壓縮尺寸（節省記憶體與加速訓練）
        self.reset()
    
    def preprocess(self, frame):
        if self.use_gray:
            frame = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
        frame = cv2.resize(frame, self.state_shape)
        return frame.astype(np.uint8)

    def reset(self):
        self.game = Game()
        # 初始化score相關的變數
        self.last_kills = 0
        self.last_health = 100
        self.last_gun = 1
        self.last_lives = 1
        self.health_stable_count = 0
        #self.last_score = 0
        self.frames_since_score = 0
        self.last_hit_radius = 0  # 記錄上次擊殺隕石的半徑
        self.last_move_action = None
        self.move_repeat_count = 0


        
        self.frames = []
        self.game.draw()  # 更新 self.state
        frame = self.preprocess(self.game.state)

        # 初始化 frame stack
        self.frames = [frame for _ in range(self.frame_stack)]
        return np.stack(self.frames, axis=0)  # shape: (4, 84, 84)

    def step(self, action):
        self.game.update(action)
        #self.game.draw()  # 更新 self.state
        # 根據 render_mode 決定是否顯示畫面
        if self.render_mode:
            self.game.draw(pygame.display.get_surface())  # 顯示畫面
        else:
            self.game.draw()  # 不顯示畫面，畫在 off-screen surface

        next_frame = self.preprocess(self.game.state)
        self.frames.pop(0)
        self.frames.append(next_frame)
        next_state = np.stack(self.frames, axis=0)

        # 設計 reward：可調整
        reward = 0
        done = not self.game.running
        info = {'score': self.game.score}

        # === 前狀態 ===
        prev_health = self.last_health
        prev_kills = self.last_kills
        prev_gun = self.last_gun
        prev_lives = self.last_lives


        # === 殺敵獎勵 ===
        if self.game.kills > prev_kills:
            radius = getattr(self.game, "last_hit_radius", 20)
            if self.game.player.sprite.gun == 2:  # 雙槍下成功命中
                reward += 3.0
            else:
                reward += 2.0 if radius >= 25 else 1.0
            self.frames_since_score = 0
        else:
            # 射擊但沒命中（這裡你需額外偵測玩家是否剛開槍但沒有擊殺）
            if action == 3 and self.game.kills == prev_kills:
                reward -= 0.1
            self.frames_since_score += 1

        # === 懲罰連續左右移動（避免無效擺動）===
        if not hasattr(self, 'last_move_action'):
            self.last_move_action = None
            self.move_repeat_count = 0

        if action in [1, 2]:  # 左 or 右
            if self.last_move_action == action:
                self.move_repeat_count += 1
            else:
                self.move_repeat_count = 1  # 重設
                self.last_move_action = action
        else:
            self.move_repeat_count = 0
            self.last_move_action = None

        # 若重複左右橫移超過 6 次，給予懲罰
        if self.move_repeat_count >= 6:
            reward -= 0.2

        # === 成功閃避障礙物（血量穩定 N 幀）===
        if hasattr(self, 'health_stable_count'):
            if self.game.player.sprite.health == prev_health:
                self.health_stable_count += 1
            else:
                self.health_stable_count = 0
        else:
            self.health_stable_count = 0

        if self.health_stable_count >= 3:
            reward += 0.1

        # === 判斷是否有高速石頭靠近玩家 ===
        danger_rocks = []
        player_x, player_y = self.game.player.sprite.rect.center

        for rock in self.game.rocks:
            if rock.speedy >= 6:  # 高速石頭定義（你可以自己微調）
                rock_x, rock_y = rock.rect.center
                dist = np.linalg.norm(np.array([player_x, player_y]) - np.array([rock_x, rock_y]))
                if dist < 100:  # 危險範圍內的高速石頭
                    danger_rocks.append((rock, dist))

        # 如果有高速石頭靠近，鼓勵往遠離的方向移動
        if danger_rocks:
            # 選擇最近的一顆來計算方向
            nearest_rock, _ = min(danger_rocks, key=lambda x: x[1])
            rock_x = nearest_rock.rect.centerx
            player_x = self.game.player.sprite.rect.centerx

            # 如果石頭在左邊 → 鼓勵往右移動（action=2）
            if rock_x < player_x and action == 2:
                reward += 0.5
            # 如果石頭在右邊 → 鼓勵往左移動（action=1）
            elif rock_x > player_x and action == 1:
                reward += 0.5
            else:
                # 如果朝危險方向移動 → 懲罰
                reward -= 0.5


        # === 補血獎勵 ===
        if self.game.player.sprite.health > prev_health:
            if prev_health <= 50:
                reward += 4.5  # 血量低時吃補血
            else:
                reward += 3.0

        # === 撿到 gun 獎勵 ===
        if self.game.player.sprite.gun > prev_gun:
            reward += 3.0

        # === 主動接近補給品 ===
        for item in self.game.powers:
            dist = np.linalg.norm(np.array(self.game.player.sprite.rect.center) - np.array(item.rect.center))
            if dist < 80:  # 判定接近距離
                reward += 0.5
                break

        # === 損血懲罰 ===
        if self.game.player.sprite.health < prev_health:
            reward -= 1.0

        # === 死亡懲罰 ===
        if self.game.player.sprite.lives < prev_lives:
            reward -= 5.0
            done = True

        # === 存活每幀鼓勵 ===
        reward += 0.0017

        # === 太久沒得分懲罰 ===
        if self.frames_since_score >= 200:
            reward -= 5.0
            self.frames_since_score = 0


        # === 更新紀錄 ===
        self.last_kills = self.game.kills
        self.last_health = self.game.player.sprite.health
        self.last_gun = self.game.player.sprite.gun
        self.last_lives = self.game.player.sprite.lives

        self.last_move_action = action  # 更新這一步的動作

        # 0623_923分
        # reward = 0

        # # 擊殺敵人：+5 分
        # if self.game.kills > self.last_kills:
        #     reward += 5

        # # 被擊中：-3 分
        # if self.game.player.sprite.health < self.last_health:  # 預設滿血 100
        #     reward -= 3

        # # 成功閃避：假如 agent 維持 3 幀血量都沒變，代表沒被打 → 獎勵閃避
        # if self.health_stable_count >= 3:
        #     reward += 0.5  # 鼓勵持續閃避攻擊

        # # 每一幀判斷是否血量沒變
        # if self.game.player.sprite.health == self.last_health:
        #     self.health_stable_count = getattr(self, 'health_stable_count', 0) + 1
        # else:
        #     self.health_stable_count = 0


        # # 存活每幀：+0.01，鼓勵生存
        # reward += 0.01

        # # 更新紀錄
        # self.last_kills = self.game.kills
        # self.last_health = self.game.player.sprite.health
        # self.last_health_stable_count = self.health_stable_count
        # self.last_score = self.game.score

        info = {'score': self.game.score,
                'reward_total': reward,
                'player_health': self.game.player.sprite.health,
                'kills': self.game.kills}

        # debug log：印出擊殺數、血量、得分變化
        if hasattr(self, 'step_counter'):
            self.step_counter += 1
        else:
            self.step_counter = 1

        if self.step_counter % 200 == 0:
            print(f"[Step {self.step_counter}] Reward: {reward:.2f} | Kills: {self.game.kills} | Health: {self.game.player.sprite.health} | Score: {self.game.score}")



        return next_state, reward, done, info

    def render(self):
        self.game.draw(pygame.display.get_surface())  # 顯示畫面

    def get_score(self):
        return self.game.score
