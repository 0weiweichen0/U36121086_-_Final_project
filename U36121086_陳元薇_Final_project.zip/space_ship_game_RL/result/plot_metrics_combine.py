#plot_metrics_combine.py
# 使用train_dqn.py中的參數(all_losses, reward_log)，用於畫圖呈現訓練的視覺化結果
# 需要時執行以下code就可以獲得圖片
# cd space_ship_game_RL/result
#python plot_metrics.py
# 結合訓練結果產出圖

import os
import numpy as np
import matplotlib.pyplot as plt

# 路徑設定 (root 目錄: space_ship_game_RL)
DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'train')

# 1-500
losses_part1 = np.load(os.path.join(DATA_DIR, "all_losses_1_500.npy"))
rewards_part1 = np.load(os.path.join(DATA_DIR, "reward_log_1_500.npy"), allow_pickle=True)


# 501-800
losses_part2 = np.load(os.path.join(DATA_DIR, "all_losses_501_800.npy"))
rewards_part2 = np.load(os.path.join(DATA_DIR, "reward_log_501_800.npy"), allow_pickle=True)

# 801-900
losses_part3 = np.load(os.path.join(DATA_DIR, "all_losses_801_1300.npy"))
rewards_part3 = np.load(os.path.join(DATA_DIR, "reward_log_801_1300.npy"), allow_pickle=True)

# 合併 loss（1D array）
#losses_combined = np.concatenate([losses_part1, losses_part2])
losses_combined = np.concatenate([losses_part1, losses_part2, losses_part3])

# 合併 reward_log（每筆為 [step, reward]）
#rewards_combined = np.concatenate([rewards_part1, rewards_part2])
rewards_combined = np.concatenate([rewards_part1, rewards_part2, rewards_part3])

import numpy as np

reward_log = np.load(os.path.join(DATA_DIR, "reward_log_combined.npy"), allow_pickle=True)
steps = np.array([step for step, _ in reward_log])
gaps = np.where(np.diff(steps) > 10000)[0]  # 你也可以把 10000 改大一點試試

for i in gaps:
    print(f"⚠️ Gap between step {steps[i]} and {steps[i+1]} (gap = {steps[i+1] - steps[i]})")


np.save(os.path.join(DATA_DIR, "all_losses_combined.npy"), losses_combined)
np.save(os.path.join(DATA_DIR, "reward_log_combined.npy"), rewards_combined)

# ========
# 讀取儲存的 numpy 檔或算法裡的資料
# ========
LOSS_PATH = os.path.join(DATA_DIR, 'all_losses_combined.npy')
REWARD_LOG_PATH = os.path.join(DATA_DIR, 'reward_log_combined.npy')

# ========
# 1. 當 all_losses.npy 存在時
# ========
if os.path.exists(LOSS_PATH):
    losses = np.load(LOSS_PATH)
    plt.figure(figsize=(10, 5))
    plt.plot(losses, label="Loss")
    plt.title("Training Loss over Steps")
    plt.xlabel("Training Step")
    plt.ylabel("Loss")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
#    plt.savefig("loss_curve_1_800.png")
    plt.savefig("loss_curve_1_1300.png")
    plt.show()
else:
    print("No loss data found at:", LOSS_PATH)
    print(f"📈 Combined loss entries: {len(losses_combined)}")

# ========
# 2. 當 reward_log.npy 存在時
# ========
if os.path.exists(REWARD_LOG_PATH):
    reward_log = np.load(REWARD_LOG_PATH, allow_pickle=True)
    steps, rewards = zip(*reward_log)

    plt.figure(figsize=(10, 5))
    plt.plot(steps, rewards, label="Reward")

    # 加上移動平均曲線
    if len(rewards) >= 20:
        kernel = np.ones(20) / 20
        smoothed = np.convolve(rewards, kernel, mode='valid')
        plt.plot(steps[19:], smoothed, label="Smoothed Reward (20)", color='orange')

    plt.title("Episode Reward vs. Global Step")
    plt.xlabel("Global Step")
    plt.ylabel("Reward")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
#    plt.savefig("reward_curve_1_800.png")
    plt.savefig("reward_curve_1_1300.png")
    plt.show()
else:
    print("No reward_log data found at:", REWARD_LOG_PATH)
    print(f"📈 Combined reward entries: {len(rewards_combined)}")
