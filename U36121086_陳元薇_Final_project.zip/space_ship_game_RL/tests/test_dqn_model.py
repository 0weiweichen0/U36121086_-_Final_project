# test_dqn_model.py
# 用於測試checkpoints資料夾中，已經被訓練的模型

import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import torch
from envs.space_shooter_env import SpaceShooterEnv
from agents.dqn_agent import DQNAgent
import time
import pygame


# 載入模型
# 自動取得正確的 checkpoints 路徑（假設從 tests 資料夾執行）
current_dir = os.path.dirname(__file__)
model_path = os.path.abspath(os.path.join(current_dir, '..', 'checkpoints', 'dqn_episode_800.pth'))

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 建立環境（打開畫面）
env = SpaceShooterEnv(render_mode=True)

# 建立 agent，並載入訓練好的模型
agent = DQNAgent(state_shape=(4, 84, 84), action_dim=4, device=device)
agent.policy_net.load_state_dict(torch.load(model_path))
agent.policy_net.eval()  # 進入推論模式

# 測試一次模型表現
state = env.reset()
done = False
total_reward = 0

while not done:
    # 為了不修改dqn_agent改成以下兩句
    agent.epsilon = 0.0  # 強制不探索
    action = agent.select_action(state)
    
    next_state, reward, done, info = env.step(action)
    env.render()
    state = next_state
    total_reward += reward
    time.sleep(1/60)  # 避免畫面跑太快（FPS=60）

print("⏸ 遊戲結束，請手動關閉視窗以結束程式")
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    env.render()



print(f"🎮 測試結果總分：{info['score']}")
